﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using MyLibLouis2.BrailleTranslator;


namespace MyLibLouis2
{
    class Program
    {


        static string tableList = "./tables/en-us-g1.ctb,hyph_en_US.dic";
        static StringBuilder inbuf = new StringBuilder(256);
        static StringBuilder outbuf = new StringBuilder(256);
        static int inlen = 255;
        static int outlen = 255;




        static void Main(string[] args)
        {

            string str = LibLouis.lou_version();
            Console.WriteLine("Yes, the lou_version() returned {0}", str);


            inbuf.Append("abcasdf 123");
            Console.WriteLine("inbuf is {0}", inbuf.ToString());
            Console.WriteLine("outbuf is {0}", outbuf.ToString());
            Console.WriteLine("inlen is {0}", inlen.ToString());
            Console.WriteLine("outlen is {0}", outlen.ToString());
            Console.WriteLine("tableList is {0}", tableList);




            int result;
            result = LibLouis.lou_translateString(tableList, inbuf, ref inlen, outbuf, ref outlen, null, null, 0);

            Console.WriteLine("result is {0} ", result);
            Console.WriteLine("inbuf is {0}", inbuf.ToString());
            Console.WriteLine("outbuf is {0}", outbuf.ToString());
            Console.WriteLine("inlen is {0}", inlen.ToString());
            Console.WriteLine("outlen is {0}", outlen.ToString());
            Console.WriteLine("tableList is {0}", tableList.ToString());





            Console.WriteLine("hello from myLibLouis2!");
            Console.ReadLine();
        }
    }
}
